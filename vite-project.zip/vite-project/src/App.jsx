import React from "react";
import "./App.css";
import img1 from "./assets/image1.jpg"
import img2 from "./assets/image2.jpg"
import img3 from "./assets/image3.jpg"
import img4 from "./assets/image4.jpg"
import img5 from "./assets/image5.jpg"
import img6 from "./assets/image6.jpg"


const experiences = [
  {
    title: "Lunch with fashion icon Lenny Niemeyer in her home",
    location: "Rio de Janeiro, Brazil",
    price: "₱5,991",
    image: img1 
  },
  {
    title: "Hit the ice with Paralympian Andrea Macri",
    location: "Turin, Italy",
    price: "₱1,735",
    image: img2
  },
  {
    title: "Create seasonal ikebana with Watarai Toru",
    location: "Kamakura, Japan",
    price: "₱5,572",
    image: img3
  },
  {
    title: "Fence and take photos with Olympian Enzo Lefort",
    location: "Paris, France",
    price: "₱8,476",
    image: img4
  },
  {
    title: "Dine in a live art show at the Palazzo Castiglioni",
    location: "Milan, Italy",
    price: "₱5,806",
    image: img5
  }

];

export default function App() {
  return (
    <div className="App">
      {/* Header */}
      <header>
        <div className="logo">airbnb</div>
        <nav className="nav-tabs">
          <div className="nav-item">🏠 Homes</div>
          <div className="nav-item">🧭 Experiences <span className="new-badge">NEW</span></div>
          <div className="nav-item">🛎️ Services <span className="new-badge">NEW</span></div>
        </nav>
        <div className="menu-icons">🌐 ☰</div>
      </header>

      {/* Search Bar */}
      <div className="search-bar">
        <input className="search-input" placeholder="Where" />
        <input className="search-input" placeholder="Date" />
        <input className="search-input" placeholder="Who" />
        <button className="search-button">🔍</button>
      </div>

      {/* Originals Section */}
      <section className="originals-section">
        <h2 className="originals-title">Airbnb Originals ›</h2>
        <div className="cards-container">
          {experiences.map((exp, index) => (
            <div className="card" key={index}>
              <img src={exp.image} alt={exp.title} />
              <div className="label-original">Original</div>
              <div className="card-content">
                <div className="card-title">{exp.title}</div>
                <div className="card-location">{exp.location}</div>
                <div className="card-price">From {exp.price} / guest</div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
